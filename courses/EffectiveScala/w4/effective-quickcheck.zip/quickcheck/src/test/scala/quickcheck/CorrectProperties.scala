package quickcheck

import org.scalacheck.{Arbitrary, Gen, Prop}
import org.scalacheck.Arbitrary.*
import org.scalacheck.Gen.*
import org.scalacheck.Prop.*

trait CorrectProperties extends HeapProperties:
// The content of this file has been removed from the handout.
// It is used by the grading infrastructure to provide better feedback.
end CorrectProperties
