
# Snippets from Parallel Programming Lectures

[![Build Status](https://travis-ci.org/axel22/parprog-snippets.svg?branch=master)](https://travis-ci.org/axel22/parprog-snippets)

This repository contains public snippets from the Parallel Programming course on Coursera.
