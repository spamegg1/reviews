package timeusage

import org.apache.spark.sql.{ColumnName, DataFrame, Row}
import scala.util.Random
import scala.util.Properties.isWin

class TimeUsageSuite extends munit.FunSuite:
  println("You can add tests here")
