void test_isalpha(void);
void test_isdigit(void);
void test_isalnum(void);
void test_areupper(void);
