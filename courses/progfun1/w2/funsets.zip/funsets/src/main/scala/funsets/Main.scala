package funsets

object Main extends App:
  import FunSets.*
  println(contains(singletonSet(1), 1))
