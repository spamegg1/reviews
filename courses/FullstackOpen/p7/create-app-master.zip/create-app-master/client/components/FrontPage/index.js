import React from 'react'

const FrontPage = () => (
  <>
    Welcome
    <a href="/messages">Messages</a>
  </>
)

export default FrontPage
