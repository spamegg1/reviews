package observatory
import Signal.Var

trait Interaction2Test extends MilestoneSuite:
  private val milestoneTest = namedMilestoneTest("interactive user interface", 6) _

  // Implement tests for methods of the `Interaction2` object

