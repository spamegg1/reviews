package observatory


trait ManipulationTest extends MilestoneSuite:
  private val milestoneTest = namedMilestoneTest("data manipulation", 4) _

  // Implement tests for methods of the `Manipulation` object

